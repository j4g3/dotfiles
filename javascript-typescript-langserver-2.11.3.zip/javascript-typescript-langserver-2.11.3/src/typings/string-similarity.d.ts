declare module 'string-similarity' {
    export function compareTwoStrings(a: string, b: string): number
}
